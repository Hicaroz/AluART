# AluARTmx AR v2 — Panel + QR

Prototipo estático para administrar cuadros AR.

## Qué incluye
- Panel `admin/index.html`
- Alta de cuadros con ID, nombre, URL del video e imagen objetivo
- Generación automática de QR en PNG/SVG usando QRCode.js desde CDN
- Listado local de cuadros
- Botón para abrir la experiencia AR
- Botón para descargar el QR
- Página `ar/index.html` preparada para MindAR
- Datos guardados en localStorage para demo

## Importante
Esta v2 es un prototipo frontend. Los datos y archivos todavía NO se suben a un servidor.
Para producción se necesita backend/almacenamiento (por ejemplo Cloudflare Workers/R2 o Supabase) para que los cuadros funcionen desde cualquier teléfono.

MindAR puede ejecutarse como HTML estático y detectar imágenes desde la cámara del navegador.
